export const environment = {
  production: true,
  mapboxKey: 'pk.eyJ1IjoibGR4MjMiLCJhIjoiY2w4YzFubjBwMDRqdjN3cXhlYnhkdWRqYyJ9.eoZwziH5PJr2UmixzXPVpA',
  firebaseConfig: {

    apiKey: "AIzaSyDVYFEsW25AiabtLqpvGq9CrMz0TMul4zQ",
  
    authDomain: "tellevoapp-39af7.firebaseapp.com",
  
    projectId: "tellevoapp-39af7",
  
    storageBucket: "tellevoapp-39af7.appspot.com",
  
    messagingSenderId: "757104709322",
  
    appId: "1:757104709322:web:825cc73cebeb074e39ae33",
  
    measurementId: "G-YE9SGWK5CN"
  
  }
};
